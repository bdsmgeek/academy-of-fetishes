# Version 1.01.03

Hello!  I'm excited to release this version, because I added a feature that allows you to play as a non-binary main character.  If you identify as non-binary, I hope this feature makes the game more immersive for you.

Not only that, but three new images have been added to the game.  One is of Kira and Mia with Max, one is of Olivia spanking Mia, and one is of Olivia as a punk rocker.  Here's an example of that last one: https://academyoffetishes.com/images/olivia_punk_rocker.png  Also, four black and white images have been colorized.

Lastly and least important, I added some javascript so the scrollbars would render correctly on newgrounds.

I hope you enjoy the game!  I'd love to hear your thoughts.

# Version 1.01.02

On a really old save, camera scenes wouldn't load.  I've fixed this.

# Version 1.01.01

Although this is labeled a minor release, a lot of effort went into this one.  Seven colorized images were added (these were originally black and white.  Here's an example of one:  https://academyoffetishes.com/images/olivia_enf.png  This is you and Mrs. Curie embarrassing Olivia by making her strip down in front of the class.

A WHOLE BUNCH of typos were fixed.  When I say a WHOLE BUNCH, I mean, like, over 500!  This will make the game a lot more enjoyable for everyone. I know whenever I notice a typo, it really ruins the immersion for me.

Almost all these typos were reported by darkdreaming over a period of months.  He's almost wholly responsible for this release and he's also an erotic lit author.  I encourage you to out his works at https://www.reddit.com/r/WitchThelma/  I really enjoyed his stories, and maybe this is TMI, but they turned me on like crazy.  

I also fixed a bug where if you would refresh the browser, your yearbook data would disappear.  Unfortunately, I couldn't figure out how to get this working on old saves, just new ones.  But there's a workaround on old saves: If you save your progress, your yearbook data will be saved there, too.  So if you ever accidentally refresh, going back to your last save will return it to the way it was.  Sorry I couldn't figure out how to make this fix backwards compatible :(

I wanted to talk again about the new game I'm working on.  I've decided to call it, "Farm of Fetishes."  It's going to be very similar to "Cook, Serve, Delicious!" only with a livestock-girl theme.  e.g., Cat girls, pig girls, bird girls, hucows, etc.  So if the idea of caring for cute livestock girls on a farm is appealing to you, you might be interested in my new game.  As I said, it's in the very early stages, so keep a look out on my Patreon for updates.  And if you've never heard of "Cook, Serve, Delicious!" here's a gameplay vid of it: https://www.youtube.com/watch?v=ItTM08_zFKE&t=158s 

I hope you enjoy this release!

# Version 1.01.00

This release adds a lot of colored images to the game and one new one that I can't discuss for various reasons.  But, here's a squirting pic that was newly colorized:  https://academyoffetishes.com/images/mia_squirts_on_olivia.png  

This release also adds a new scene with Olivia and a... friend.  For various reasons, I can't discuss that one either.  Let's just say, if you liked the scene with Mia, Kira, and Max, you'll probably like this one, too.  Sorry for being so secretive, but if you play it, you'll know why.  You'll unlock this new scene at the end of the game, after you play the Mia, Kira, and Max scene.  I apologize for shilling, but $5 pledges have access to a cheat that skips right to it.  

I also wanted to talk about my new game I'm working on.  It's so new, it doesn't even have a name yet.  But, it's going to be very similar to "Cook, Serve, Delicious!" only with a Hucow theme.  So if the idea of caring for cute human-cow girls on a farm is appealing to you, you might be interested in my new game.  As I said, it's in the very early stages, so keep a look out on my Patreon for updates.  If you've never heard of "Cook, Serve, Delicious!" here's a gameplay vid of it: https://www.youtube.com/watch?v=ItTM08_zFKE&t=158s 

Happy Holidays everyone!

# Version 1.00.02

Fixed a bug where I forgot to close an if statement.

# Version 1.00.01

Accidentally forgot the label for "snot" on the fetish picker.

# Version 1.00.00
I'm happy to announce version 1 of Academy of Fetishes!  Baring small improvements (new images, bug fixes, etc.), this concludes development of the game!  Though, I can't rule out adding a new scenes in the future, I can't promise it either.  

I really hope you like the ending and the game in general.  I know it has some extreme fetishes in it, but I wanted the ending to appeal to most people.  It's basically an orgy where you fuck and get fucked by lots of students.  I will now go into detail about what's new in this release.

- There's a massive orgy scene at the end of the game I referred to above.
- You wander the halls and observe the students and their lewd casual wear.  
- I made Mia's nipples dark in my descriptions instead of pink.  Someone long ago let me know that most Asians have dark nipples.  I'm not sure if that's always true, but a little "research" seemed to confirm it.
- I wrote a really nasty scene with Mia, Kira, and "Max."  It's only available to those with extreme fetishes.  If you're squeamish, it probably won't be available in your play through.  But, in the off chance that you stumble upon it, it has three warnings before you'll be able to read it.
- Camera scenes no long appear randomly.  Now, they're always available.  I was concerned that some play throughs wouldn't get to see everything, and it felt mean to make people play the game all over again just to see the one camera scene that randomly didn't appear.
- There are two new images.  One is of Anna pony training Hannah.  The other is of Olivia tied up to her bed.  Here's a picture of the former:  https://academyoffetishes.com/images/anna_trains_hannah_pony.png
- There are two old images that have been colorized.  
- The game is now 397k words long.  That's like four novels worth of content.
- This bullet point contains SPOILERS, so skip if you don't want to be spoiled: There's a new scene where you discover how AB (the anonymous benefactor) always seems to slip your grasp when you're trying to catch them.

You are probably wondering what's next for me.  That's something I'm still trying to figure out.  Right now I feel like I want to explore the Unity game engine.  I want my next game to emphasize game play elements, as opposed to Academy of Fetishes which is basically a Choose Your Own Adventure.  Please keep an eye on my patreon for updates of what's next.  

Again, I hope you enjoy my game!

# Version 0.31.00

To summarize this release, there are two new scenes, 10 full colored images, and "lore" changes.

* For your convenience, you can now "click" on links by pressing numbers on the keyboard.  E.G., the first link on the page can be clicked by pressing 1, the second link can be clicked by pressing 2, and so on...
* Lore change: It's not possible for you to record anything on camera.  This was necessary to keep AB mysterious.  I think I do a decent job of justifying it.
* Lore change: The school never received government funding.  It was and has always been private funded.
* Lore change: If you play as a Futa main character, it is now Ms. Waterloo who gets you to reveal it to the school, not Ms. Darwin.
* There's a brand new image of Mia dressed up as a cat girl in the costume show: https://academyoffetishes.com/images/mia_felicia_costume.png
* There's a brand new image of Kira on all fours while Casey pulls rosary beads from her vagina.
* My artist colorized 8 old black and white images.
* On the discord server, you gain XP for chatting and then you can level up.  I tried to make fun roles for your levels, like "student", "tutor", and "teacher."
* I wrote scene that is a commission request for someone to eat scat, but for them to enjoy it.  In the end, I felt Kira was the best candidate, because she already had a scene where Mrs. Ball trained her in this.  This new scene takes place in the cafeteria, and as you would guess, it's really filthy.  Please keep in mind, it's easy to avoid and it's very late in the game, so don't let this scare you off from trying the game :)  Annnnd just to scare you off again, this scene contains snot and vomit, too.  
* I added "snot" to the fetish picker, so when you start the game, you can say you're not interested in seeing this fetish, and it won't show up.
* The word count is now 375k.  This released added 9k words.

And now, there's a MAJOR SPOILER below that discusses the 2nd scene added:

* You chase AB (the Anonymous Benefactor) down the school hall. I'll leave it at that, because I don't want to give anymore away.

# Version 0.30.00

This release adds two new scenes, 8 full colored images, and "lore" changes.  Details below:

* Added a new scene where the students wear lewd swimsuits in Ms. Waterloo's class.  If you decide to have a costume show, Ms. Monet (the art teacher) will be inspired to come up with new swimsuits for swim class, too.  Most of them are creative variations of micro bikinis and fail to contain the students' private parts in one way or another.  Of note, Olivia has a special transparent plastic suit if you go down her diaper path (optional).
* I added a new scene that's pure story/no sex.  This one is short, but it reveals something critical about AB.  I won't reveal what.  This scene is unlocked after you finger Olivia in biochem class.  
* More than half the images are black and white, but I've started paying my artist to go back and color in the old ones.  Seven old images have been colorized, and I think they look great!  Here's a few examples: https://imgur.com/a/WEqTrd2
* A new image was added.  This is of Kira holding her full belly after her (optional) binging scene.  
* New cheats were added that let $5 pledges skip directly to the new scenes.
* I went back and tweaked the story in certain places.  These changes are critical to the story line, yet tiny in size.  Since the game's 366k words now (6k words added in this release alone), finding these changes would be like finding a needle in a haystack.  Therefore, I'm going to summarize them below for those that don't want to read through the whole game just to find what's new.  But, these notes should be considered SPOILERS.  Here they are:






SPOILER WARNING:
* I've made the cameras true closed circuit cameras. This means the Anonymous Benefactor can't see what you see unless you choose to send them a recording.  Because of limited storage space, you usually don't record scenes unless you're actively watching it.
* After Olivia's fisting scene, you type up an email to AB and say which lube you used on her.  This will unlock a scene with a MAJOR SPOILER.
MAJOR SPOILER BELOW:







MAJOR SPOILER:
* AB replies to your email and mentions that they wish you used a specific type of lube instead.  The thing is, you never mentioned what kind of lubes there were to choose from, so the only way AB could have known about the alternative lube is if AB was in the school...  There's more to this scene than I'm saying, but I'll leave it at that.

# Version 0.29.01

If you chose watersports for Mia's kitty costume, you'd also get the scat scene, even if you didn't want scat.  This has been fixed.

# Version 0.29.00

Time for a costume show!  This release adds a 9k word scene with a ton of variety to it.  Ms. Monet, the art teacher, comes to you asking if she can put on a costume/fashion show and if you agree, the fun starts when the week ends.  A stage is setup in the gym, and the student's show off the cute outfits they made.  

If you don't want to be spoiled as to what the costumes are, you should stop reading now:

* Jessie dresses up as a cowgirl.  There are different versions of this scene depending on if she's "normal", lactating, or a hucow.
* Casey and Kira dress up as a nun and peasant, respectively.
* Olivia dresses up as a punk rocker and shows off her real/fake piercings (your choice)
* Anna and Hanna (the twins) dress up in heavy latex gear.  Their mom joins in with the fun if you have moms at the school.
* Mia dresses up as a cat girl and does some naughty things.
* Amy, Olivia, and Luna (the trans girl) or Sarah (the cis girl) dress up as flowers and bees and "pollinate" each other.  

Here are some other relatively minor additions: 
* This release adds a new image of Kira visiting the nurse's office when she's sick.  
* I fixed a bunch of double newline issues at the office, but I'm sure I have more.
* I added new cheats to skip directly to this new scene and all the old ones (pledges only)
* The total word count is now 360k!

For the next release, I plan to add a new scene with lewd swimsuits like these: https://i.imgur.com/7373ieQ.jpg

# Version 0.28.03

The previous release introduced a massive bug that made it so old saves couldn't be loaded.  This fixes that.

# Version 0.28.02

Now you can't make security camera scenes appear/reappear by repeatedly checking on the yearbook then clicking back.

# Version 0.28.01

"In ver 0.28 Bailey's blowjob scene not working. If you click on the link, it says: the passage TransMilkMachineBaileyCumBlowjob does not exist"  Fixed this.  

# Version 0.28.00

This release is all about sex machines and trans girls.  There are three machines to play with: An edging machine, a gynecologist chair with lots of vibrators, and a torture machine.  The edging machine gives Fifa or Tiffany (your choice) a long, drawn out buildup before they have an orgasm.  The gynecologist chair restrains Lucy's legs by her ears, then you attach vibrators all over her erogenous zones.  And finally, the torture machine is for Bailey, a masochist who loves having her penis and testicles, well... tortured.  

All three scenes are optional, and they all have at least two endings.  For example, you can give Bailey a ruined orgasm with a feather, or give her a painful blowjob.  You can have Ms. Tink and Kira give Lucy an orgasm by giving her a handjob, or you can have anal sex with Lucy instead.

There's lots of fetishes in these scenes.  Off the top of my head, we've got:

- Trans girls
- Bondage
- Gynecologist themes
- Vibrators
- CBT (Cock and Ball Torture)
- Handcuffs
- Making out
- Edging
- Ruined orgasms
- Condoms
- Anal sex
- Anal winking
- Enemas (optional)

There are other important changes in this release that are unrelated:

- I made the radio buttons more user friendly.  Now each radio button is on the left of the text, and each radio button is on its own line.  Sometimes, it was confusing what you were selecting, especially because this used to be inconsistent.
- There are two new images.  One of Mia blowing the MC with urine dribbling down her chin, and one of Olivia getting her anus vacuum pumped.
- On Patreon, $1 pledges have access to scenes that, for one reason or another, couldn't fit into the game.  I tagged these exclusive content posts so they're easy to find.
- In the yearbook, Nurse Neadle was showing up in the list of students.  I've moved her to the list of teachers. 
- In the swimsuit scene (the one where they turn transparent when wet), I'm now using the colorized version of the image, not the black and white one.  Here's the colorized version: https://academyoffetishes.com/images/new_swimsuits.png
- The game is now 351k words.  This release added 18k words.

# Version 0.27.01

I fixed two bugs:

1. After you kidnapped Hannah, you would not be able to follow up with future scenes between her and Anna
2. If Jessie was lactating but not a hucow, there was one scene that described her as a hucow anyway.

# Version 0.27.00

This release adds 3-4 scenes to the game and two new images of Jessie hooked up to the milking machine.

- The first scene involves a milking table.  If you've never heard of them, it's basically a desk with a hole through it, and you lay on top of it and stick your penis through, and someone underneath strokes you.  This scene has two parts: First, Luna, the well endowed trans girl, lays on top while Claire and Sarah stroke her from underneath.  It should be noted that Claire and Sarah are mother and daughter, respectively.  After the three of them have their fun, you have the chance to take Luna's place and go up top.  The whole class has their way with you until you have an orgasm.  Unfortunately, this last part is only available if your character has a penis.  This scene includes BDSM, hogtying, and milking tables.
- I revamped the Pony Girl PE Class in a lot of ways.  First, I identified the trainer and the pony girl in the prancing scene as Anna and Hannah, the twins.  I added a few passages where you have the option to ride on Hannah's back as Anna leads her around the farm.  In another part of this scene, you now have the option to be "bred" by Luna.  As mentioned above, she's very well endowed.  In this scene, she will penetrate your anus, but it's available to all types of main character.  Ignoring the content that was already there, this scene now has twincest, lift and carry, anal sex, leather, latex, and cock socks.
- If you had both male and female genitalia, it was something you kept a secret from the rest of the school.  I created a scene where you reveal your secret to everyone.  This scene isn't too sexual, but it does take place in a shower.
- I fixed a bunch of typos in old scenes that a fan was kind enough to inform me of.  Thank you!
- I fixed a bug where Jessie would be lactating in her Hall Pass scene even if you chose to not have her lactate.
- I fixed a bug where if you ended chastity week early, it would still let you play the other chastity week scenes.
- I added two pictures for Jessie being milked by the machine.  Here's the one where she's a human: https://academyoffetishes.com/images/milking_machine_human.png
- The total word count is now at 333k words, adding 13k words to the game.
- For those wondering what's planned in the future, I have created a roadmap to v1.0. You can read about it here: https://www.patreon.com/posts/road-to-v1-0-19997343

# Version 0.26.02

If you said you wanted to skip chastity week, you still saw chastity week scenes.  I fixed this bug.

# Version 0.26.01

If you said you didn't want to spank the pony girls, you'd end up spanking them.  I fixed this bug.

# Version 0.26.00
This release adds two (well, really four) new scenes to farm week.  The first is a PE class that takes place on the farm, the second is a camera scene.  I'll go into these and other changes in detail:

- In the PE class, Mrs. Ball has half the students dress up as pony girls and the other half dress up as trainers.  This is really three scenes in one, because you can have the pony girls carry you in a cart, watch them get trained then "feed" one a carrot, or watch the simulated breeding program.  This scene includes these fetishes: Pony girls, crops, canes, strapons, fake cum, cum inflation, anal only orgasm, enemas.  All these hard ones are easily avoidable while you're playing.
- The camera scene is a commission request where Mia and Olivia play with a vacuum pump.  Mia puts it on Olivia's ass, pumps it up, causes Olivia to prolapse, then plays with the prolapse.  If you're not a prolapse fan, you might want to skip this one (it's easily avoidable).  This scene contains these fetishes: Prolapse, vacuum pumps, anal destruction.
- I added an image of Ms. Tink's automated milking machine: https://academyoffetishes.com/images/milking_machine.png  Next release, I should have two more versions of this image.  One of Jessie on it when you've gone down the hucow path, and a different one if she's still human.
- I fixed a bug where the twins would act like they "interacted" even if you left the relevant scene early.
- The total word count is now at 320k words, adding 9k words to the game.
- For those wondering what's planned in the future, I have created a roadmap to v1.0. You can read about it here: https://www.patreon.com/posts/road-to-v1-0-19997343

I hope you enjoy this release.  Let me know what you think!

# Version 0.25.01

Fixed some typos.

# Version 0.25.00
Introducing farm week!  The Anonymous Benefactor decides your school should have a farm.  Here are the details of this release:

- Ms. Tink, the engineering teacher, volunteers her skills to build a milking machine, but she goes a little overboard.  You have the option to have Ms. Tink try the milking machine on herself first, or you can skip the teacher-on-teacher action and skip to a scene where you put Jessie in the machine.  Depending on the choices you've made, Jessie could be a hucow or a simply a lactating human at this point.  The story varies depending on which.  This is really two scenes: The first is where Ms. Tink introduces the machine and optionally uses it on herself.  The second is when you put Jessie into the machine.  Either way, you have the opportunity to strap Jessie in and give her multiple orgasms.
- If your main character is male or futa, you can go to the restroom and Mia will get in the stall with you.  In the stall, she encourages you to urinate so she can watch, but it becomes challenging when you're completely erect.  That's when she has the idea that if she gets you to cum first, it'll be easier.  It goes without saying this is a scene with watersports.  This scene was a commission request from a pledge.
- I went back to chastity week (AKA holy week) and added a scene where you can visit the students in the shower and/or in the restroom.  It shines some light on how it's possible to wear a chastity device for a whole week.  During these moments, they're allowed to take it off, but they're under strict supervision to prevent them from masturbating.
- This release adds two new images.  One of Luna (a trans girl) having doggy style sex with Amy (the petite cis girl).  The other is of you urinating into Mia's mouth, as described above.  Here's the former: https://academyoffetishes.com/images/luna_fucks_amy.png
- Bug fix: If the twins don't interact, now you don't get a follow up scene saying they did interact.  
- The total word count is now at 311k words, adding 19k words to the game.

As a reminder, all these scenes are optional.  Here's an incomplete list of fetishes included in this release:

- Vibrators
- Lactation
- Breast pumps
- Clit pumps
- Multiple orgasms
- Fucking machines
- Electro-stimulation
- Chastity
- Urine
- Watersports

Enjoy!  


# Version 0.24.02
Fixed some more typos.  

# Version 0.24.01
Fixed some typos.  

# Version 0.24.00
The previous release was the largest I've ever had, but this one even tops that!  At 26k words, the word count is now 292k.  There's lots of new scenes and plenty to play around with.  Before I describe the new content, I want to remind everyone all scenes are optional.  If there's a fetish you don't like, you can skip the scene at any time.  Here are the new scenes.  If you want to be surprised, skip this part:

- There's a scene where Jessie uses a hall pass to request permission to masturbate.  You have the choice of letting her do that in private, sending her to your office to watch, or making her do it in public in front of the class.  This scene contains these fetishes:  Embarrassed nude female (ENF), masturbation, public masturbation, grool, lactation.
- There's a scene where Anna sits on her twin sister Hannah's face.  Hannah's wearing an electro-stimulation chastity belt during this scene, and you give her an orgasm by turning up the power.
- There's a scene where two teachers stuff the tip of Luna's penis into her own anus.
- There's a PE competition where the trans girls are tied up and will lose if they have an orgasm from other students blowing them, but the other students will win if they get a trans girl to orgasm.  This scene contains bondage, gagging, forced orgasms, and huge insertions.
- There's a follow up to the previous scene where the losing trans girl has to stay in the bathroom gloryhole for the rest of the day.  There's a wide variety of outcomes to this depending on who lost in the previous scene.  Some of the fetishes in this scene include ruined orgasms, forced orgasms, snowball (swapping semen via kissing), cumming in chastity, cumming from anal, clothespins, cock and ball torture, watersports, and urethra play.
- There's an ending scene for Holy Week.  If you've unlocked diapers with Olivia, you can spy on Mia putting a diaper on her.  This whole ending scene contains kissing, sex toys, gaping, diapers, and female orgasms.

The overarching theme for all of these scenes is chastity belts/cages.  

Three new images were added to the game.  One of them is Olivia in her gaping chastity belt, Olivia with an inflatable butt plug in her ass, and of Bailey with her painful chastity device if she's forced into the gloryhole.

I actually removed a Jessie hucow transformation scene: The one where she suffers mental degradation if you give her too many hucow pills.  Nobody has ever told me they like this scene, and it just got in the way when I was writing the Jessie masturbation scene mentioned above.  Rather than spend time maintaining a story nobody likes, I decided to cut it out.  But, it's still technically in the game.  Those with cheat codes can jump to it, but you can't get there any other way.  Sadly, there is an image commissioned for this story that nobody will have access to now :(  https://academyoffetishes.com/images/milking_jessie.png  But, this scene may make a return in the future.

Next week will be farm week, a week where the college gets a farm.  But the first scene in farm week won't be related to the farm, I've received a commission request for Mia to give you a blowjob while you're in the restroom.  This scene will have watersports.  After that, I will have a scene where Jessie is in the farm and hooked up to lactation machines.

I hope you enjoy the release!  I put a lot of work into it!  

# Version 0.23.01
This fixes some typos and changes the location of a random survey.

# Version 0.23.00
This version of the game is all about chastity devices and belts.  At 24k words, it's the biggest release I've ever had.  There are 7 new scenes, all related to frustration and teasing.  It's not all about chastity though: There are tons of additional fetishes.  Off the top of my head, there's gaping, erotic ASMR (IE: Whispering that makes the hairs on your neck tingle), competitive sexual games, anal orgasms, and more.  

Even the chastity belts come with their own fetishes.  There's belts that provide electrical stimulation throughout the day, making the wearers go insane with lust.  There's a belt with speculums inside to keep the wearer constantly exposed and gaped.  And those are just two out of eight.

The game is now 266k words, so there's plenty to explore if you've never played it before, but if you have played before, you should know all this new content is at the end.  

Three new images were added to the game.  Here's an example: https://academyoffetishes.com/images/casey_chastity_belt.png

For the next release, I plan to add even more chastity content!  Here's an incomplete list of all the fetishes included in this list:

- Aphrodisiacs
- Anal
- Anal toys
- Anal orgasms
- Chastity belts
- Chastity devices
- Chastity bras
- Erotic ASMR
- Erotic sports/competition
- Handcuffs
- Kissing
- Latex
- Twincest

Oh, and I added some iOS meta tags to the header of the game so you can save it to your iPhone's homepage.

Enjoy!


# Version 0.22.02

Minor tweak: I changed the way I'm gathering anonymous analytics so I can tell what passage someone was on when they stopped playing.  Hopefully I can use this information to improve the game.

# Version 0.22.01

Minor tweak: After you finish the new Amy/Luna scene, there's a small chance that you'll be given a two question, anonymous survey.  It asks, "Did you like the scene?" and "Why or why not?"  It's completely anonymous and both questions are optional.

# Version 0.22.00

This release consists of a very long scene split into many different parts.  Most of it is panty and trans girl themed.  It follows petite, innocent Amy and her muscular, trans girlfriend Luna on their adventures throughout the day.  The next paragraphs will outline the scene and may contain spoilers:

It begins in their room, Luna undresses and fondles Amy.  Amy doesn't want to take her clothes off though, for reasons.  They have a little negotiation, one thing leads to another, then *Bam!* panty job.  Well, actually, before that, there's some muscle worship.  The first part ends with Luna cumming in Amy's panties and then Luna dares her to wear them throughout the day.

Amy, of course, agrees to wear the panties.  You can visit her in her next class and have a chance to make her very nervous that she's going to get caught.

Her next class is bio, and the whole hour consists of watching hardcore, closeup pornography on the projector while the teacher narrates it like a nature documentary.  In one of the films, there's some chastity, a fucking machine, and a hands free orgasm.

From there, we watch Amy and Luna reunite after class.  Amy brings Luna to orgasm by massaging her prostate.  But, unlike the film, this is not a hands free orgasm.  I figured you don't need more than one per scene.

Here are the fetishes included in this scene:

- Innocence
- Muscle worship
- FBB (Female body builder)
- Cum-filled panties
- Panty job
- Edging
- Pre-cum worship
- Pre-cum milking
- Humiliation
- Nail fetish
- Chastity
- Cumming in chastity
- Ruined orgasms
- Fucking machines

There were also 3 new pictures added this release, 2 of them are colorized.  Here's an example: https://academyoffetishes.com/images/luna_autofellatio.png

This scene is 10k words, bringing the total word count to 241k words.  Enjoy!

# Version 0.21.00

Three new scenes have been added to the game:

1. Casey steals a pair of dirty panties she finds in the laundromat and masturbates while smelling and licking them.
2. Bailey and Lucy, two trans girls, have doggy style sex in the dormitory.
3. This last scene is short and kind of two scenes sewn together.  It begins in math class. Casey is naked with her body bent over the teacher's desk while the other students measure every part of her body.  But, it gets interrupted when Olivia has an "accident" in her diaper.  Mia takes Olivia to the restroom to change her.

These three scenes add 6k words to the game, bringing the game to a total of 231k words.

I also added two new images: A makeshift nursing bra for Jessie, and Casey's panties being pulled down by Ms. Monet.  Here's an image of the latter: https://academyoffetishes.com/images/underwear_pulled_down.png

The fetish picker options are now alphabetized.

I added a setting to hide images.  This should be useful to people who want to play in public on their mobile phones.  

For the next release I'll be doing a commission request: A trans woman will cum on a cis woman's panties, then the cis woman will wear them throughout the day.

Here are the fetishes added in this release:

- Panty fetish (Sniffing, Licking, Mouth stuffing)
- Trans on trans sex
- Cream pie
- CBT (Cock and ball torture)
- ENF (Embarrassed nude female)
- Diaper


# Version 0.20.00

First of all, I wanted to announce that I finally got around to making a discord server.  I spend most of my time there sharing lewd pics and chatting with fans and I'd love for more to join me.  Here's a link to the chat room: https://discord.gg/kpEFKft

This release is all about Yuri anal stretching.  Olivia finds an inflatable butt plug and uses it on herself while Mia 'helps'.  If you're a fan of anal gapes, you're going to like this scene.

I also rewrote part of the foot fetish scene and most of the date scene between Casey and Kira.  I did this because I wanted Casey to be more sexually repressed.  That way, I figure, it'll be much more fun when she breaks out of her shell in future releases.  Hopefully you like the rewrites!  

There's now an image gallery.  A link on the left side of the menu once you've seen at least 2 pictures.

I added a new picture of Jessie's nipple being tortured with a clothespin.  You can see it here:  https://academyoffetishes.com/images/clothes_pin_to_side.png

The game is now 225k words.  Here's a list of fetishes included in this release:

- Hand holding
- Foot fetish
- Yuri
- Tease and denial
- Hands free orgasms
- Anal
- Anal worship
- Rimjobs
- Inflatable dildo
- Gaping
- Stretching
- Rosebutt

# Version 0.19.02

Fixed a bug: If you chose a ring gag or a dildo gag in Olivia's diaper scene, it would describe you putting on a ball gag after it described you putting on the gag of your choice.

# Version 0.19.01

Fixed a bug where after checking up on Olivia's diaper, you would immediately be able to check up on her without a diaper.  Now you can only check up on her one way or the other.

Also, since Olivia is subservient after her diaper scene, if you play through the diaper scene, I removed any camera scenes where where she acts dominant.

# Version 0.19.00

Diapers are the star of this release!  At 12k words, this scene is massive and there's tons of choices.  For example, you can choose to have the diapered student wear one of three different gags, or choose none.  You can tickle her to tire her out, or choose not to.  If you tickle her after you remove the diaper, there's different content than if you tickle her before you remove it.  How do you unlock this scene?  I'll tell you at the end of this changelog so others can avoid it as a spoiler.

Besides the diaper scene, I also added 3 new images to the game.  One of them is a remake of the first picture I ever commissioned for the game: https://imgur.com/a/akZb8  One is of Jessie squirting breast milk into your mug of coffee, and the last is of Yuki spreading herself for you as you and Mia shave her privates.  

Here's how you get to the new diaper scene: Near the end of the game, there is a scene where you can fist Olivia and you get to choose some mystery ingredients to add to the lube.  If you choose to use muscle relaxant in her vagina and then drip some of the lube into her urethra OR you fist her ass with muscle relaxant, when the scene ends you'll put a diaper on her.  Once you get back to your office, you'll have a choice to check up on Olivia.  That checkup is this long diaper scene.  BTW, for those that hate scat, there is only scat content if you use relaxant on her ass.  If you only use it on her vagina, it's only pee content.

By the way, the game is now 221k words!  

Here are the list of fetishes included in this scene (all of them should be easy to avoid if they're turn offs):

- Diapers
- Gags (Dildo, o-ring, ball)
- Tickling
- Bondage
- Handcuffs
- Tongue play
- Gagging
- Mind break
- Anus worship
- Vulva worship
- Anal gape
- Watersports
- Scat
- Using scat as a dildo
- Scat eating
- Vomit

# Version 0.18.00

This release adds two more scenes where Olivia is the star.  One scene focuses on her vagina, the other on her anus.  The rest of this change log will be spoilers for the new scenes, so if you know you're going to play it, you may not want to continue reading.

There was already a large scene where she was fisted in both holes.  I added a new path to that scene where you can use muscle relaxant lube on her vagina.  If you choose to do so, you also have the option to apply it on her cervix and/or her urethra.  If you apply some to her cervix, it loosens up a bit and you can slip a bit of your finger in there.  If you apply it to her urethra, she urinates in front of the class.  Later, the urethra choice will lead to a diaper scene (not yet implemented, it's planned for the next release).  For those who like diapers but dislike urethra play, I intentionally avoided any urethra play in this scene.  You simply drip some lube onto her pee hole, you don't stick anything in.

After the fisting scene, you can watch her in her room on camera.  She checks out the 'damage' done to her anus.  If Mia and her are on good terms, Mia will come to visit.  After some hesitation on both sides, Mia decides she likes Olivia's new 'look' and wants to play with it, but Olivia has more fun teasing and denying her.  The teasing gets pretty cruel (in a psychological way, not a physical way).  Tons of anus worship!

I have a new colorized banner for the game!  I should be adding one to my Patreon soon, but I want to censor it a bit, first.

I rewrote the scene where you grab the diaper from the "abandoned nurses office".  A previous update made it so the school does, in fact, have a nurse.  So now, this passage referred to the school nurse by name.

Someone informed me that if you play as male, characters still refer to you as "Ma'am".  I did my best to find all these situations and make them dynamic.  If you're male, you should be referred to as "Sir" now.

I wrapped all the radio buttons in HTML "label" elements.  That way, if you click on the text, it'll select the radio button for you.  Should be a nice UI change.

Added cheats that let you skip directly to the scenes you're interested in reading ($5 pledge reward).

If you got to the office then used the back button, you could get duplicate notifications and entries for yearbook entries.  This has been fixed, again :(

I'm pretty sure I'm forgetting some fetishes in this release, but here are the ones I can remember:

- Cervix
- Cervix fingering
- Forced urination
- Desperation
- Humiliation
- Asshole worship
- Asshole smelling
- Tease and denial
- Orgasm denial

This update adds 8k words to the game, bringing the total words to 209k.

# Version 0.17.00

This release adds two often requested features.  Ever since the game had transfer students, people have been asking for an option to play with both of them at the same time.  I changed a lot of text and code so that is now possible!  This means you can play with Tiffany, Fifa, and Beth in the pool scene on one play through.  It also means you can play with Claire and Luna in the cafeteria when they're wearing sensory deprivation headgear.

The other change is mostly about user experience.  When you got a new yearbook entry, it used to pop up this big rounded rectangle at the bottom.  It would hang around for a couple of seconds, block text, and prevent you from clicking on links if it covered them up.  I changed this so that your yearbook button flashes instead.  The yearbook button and the names of characters are colored green if there's new content to read.  I did my best to make this backward compatible so old saves will be upgraded.  But, let me know if you have any issues.

The word count is still at about 201k, as most of the changes in this release were code.

I also commissioned a new image for the lewd scavenger hunt:  https://imgur.com/a/S2U5D

Here's a long GIF of the way the new yearbook entries look.  Most people have said it's better this way: https://imgur.com/2VJPaci

This was about a weeks worth of work and I gave a poll on my patreon about what I should work on next.  The poll is still going, but it looks like the next release will be one of these:

1. Follow up on fisting Olivia:  If you give Olivia a relaxant in the fisting scene she wears a diaper after class.  You can check up on her while she's sleeping in the dorm.   This will have humiliating results.  But, if she's not wearing a diaper, you can watch her check out her well used holes in the mirror.   Maybe Mia's there offering words of encouragement?  If Mia doesn't like Olivia, you can assign her the task of reapplying the muscle relaxant every night.  This will likely include a new fisting path where you can use the muscle relaxant on  Olivia's vagina, making her incontinent. That's for the ABDL's who don't like scat. 
2. Making body casts with Ms. Monet:  For an art class Ms. Monet will make full body casts of a student.  When the cast dries, the student will be completely immobilized in that position.  It could be fun to take advantage of someone like that :)  All the sensitive parts would be exposed, of course.

# Version 0.16.03

Now you're only asked for your name once.  You used to be asked a second time when you entered Ms. Monet's class.

# Version 0.16.02

Fans discovered 4 places where I forgot to make pronouns and dialog dynamic based off of gender.  I fixed these.

# Version 0.16.01

I accidentally linked to labia_minora_instructions.jpg instead of labia_minora_instructions.png  As a result, this image wouldn't load when you played the game.

# Version 0.16.00

This release represents a major milestone!  You can now configure the main character's body parts.  You can choose the pronouns you're referred by, you can choose whether or not you have breasts, and you can choose whether you have a penis, a vagina, or both!  This means you can play as a futanari or a trans woman or a male!  For those that are new to the game, you used to only be able to play as a female (of course that's still the case).

I wanted to add this new feature with a bang (sorry), so I also added a new scene where you have sex with her.  Each scene is significantly different depending on your genitals.  About 1000 words different each, I believe.  Whether or not you have breasts also has an effect.

I had to do other minor things like change the pronouns used to refer to you, dynamically change references of your "purse" to be a "briefcase", describe your swimsuit differently, etc.  

In another major milestone, the game also hit 200k words!  201k words to be exact.  I think that's larger than some novels!  That means this release adds 14k words to the game.

Here's a list of what's new in this release:

- The Jessie sex scene (it includes more than just sex, but I'll list the fetishes at the end to avoid some spoilers) is 10k words.  It's the largest scene in this release.
- There's a scene between Ms. Waterloo, the swim teacher, and Lucy, the BBW trans girl.  They have a private lesson together.  Well, not too private, all the other students are present, but they don't interfere.
- There's a non-sexual scene where Anna learns from you that she 69'd her twin sister, Hannah.
- As I mentioned above, you can now choose your genitals, your gender, and whether or not you have breasts.
- I added a credits to the game.
- In the existing hucow scene, Jessie touches your penis instead of your vagina, if you have one.
- 4 new images were added.  Here's the tamest one of all: https://imgur.com/a/DuoIq  It's from the sexual scavenger hunt scene at the intro.
- I added new cheats to skip directly to any scene you want ($5 pledge reward)
- I used a more modern Patreon symbol for the watermarks I use for my images. 

Here's the list of fetishes included in this new content:

- Sex (OK, not a fetish.)
- Blowjob
- Deep throat
- Cumming down someone's throat
- A lip/kiss job
- Lactation
- Vacuum pumps
- Clit pumping
- Breast pumping
- Vibrating eggs
- Latex thong (Note: Not a significant component of the scene)
- Strap-on
- Inflatable dildo
- Gaping/Stretching
- Squirting
- Futa/Futanari
- Female ruined orgasms
- Swimsuits
- Crying

# Version 0.15.00

Three short-ish stories were added to this release. In my opinion, one story is softcore and the other two are really hardcore.  

Let's talk about the softcore scene first.  It involves a humiliating public pantsing of someone.  A few people requested this in the Embarrassed Nude Female subreddit ( https://reddit.com/r/ENF ).  I have no idea how this fetish works, but I had them review the finished content and they seemed to really like it. :)

The two hardcore scenes kind of go hand in hand with each other.  In scene #1, Mrs. Ball force feeds a student.  In scene #2, you take that student to the nurse to get her stomach pumped (Yes, vomit).  It's probably fair to say this update isn't for everyone, but I especially enjoyed writing the vomit scene.  I tried to make it as descriptive as possible.  Some fans of the fetish reviewed a couple of paragraphs and all had good things to say.

This update adds 7k words to the game and brings the total word word count to 187k!

In the next release, I'm going to make it so you can choose to play as a male protagonist.  A lot of people have requested this.  If I have enough time left over I'm either going to add dream sequences to the game or further some of the characters' relationships.  If I have a ton of time left over, I may do both!

Here's the official list of changes from this release:

- 3 new short stories, described above.
- Added a new image to the scavenger hunt scene: https://imgur.com/pJV1DUl
- I updated the patreon icon in the game to be more modern.
- I added a new entry to the fetish picker: Vomit.
- I fixed a bug where you could click "Skip Scene" when you reached the end of the game.  Not sure if this had any negative effects, but it wasn't intended behavior.
- I formatted the list of cheats ($5 pledges only) so that the description was on the left side.  I noticed people would copy the cheat and the description to use the cheat, so hopefully this makes it a little more obvious how to use them.

Here's the list of all the fetishes included in this release:

- ENF (Embarrassed nude female)
- Humiliation
- Bottomless
- BBW
- Forced feeding
- Mind break
- Latex gloves
- Medical fetishism
- Gagging
- Vomit

# Version 0.14.00

This new release is all about the new swimming pool.  You're also introduced to Ms. Waterloo, the new swimming teacher.  This all happens in an epic, 11k+ word scene (bringing the game to a total of 180k words).  The new teacher is something of a sex expert... a sexpert if you will.  She seduces Amy (the most petite character in the game) and gives Fifa (a tan Filipina trans girl) a powerful, yet slow, orgasm.  There's lots more to the scene, but you can discover those details when you play it :)  I'll list the fetishes at the end, as I imagine some prefer to be surprised and would want to skip it.  By the way, this scene was a commissioned idea :)

In addition to the text, this release adds 3 new pictures to the game, including one for the new swim scene.  If you want to check out that new picture, here's a link: https://imgur.com/iT4Yhlq

If you're curious what I've planned next there will be a new nurse with a hard vomit scene!  If that sounds too gross (I can't imagine it would), I plan to add a bunch of other little stories with a variety of other fetishes.  Maybe even a new dream sequence feature so we can have some unrealistic fetishes in the game.

I hope you enjoy this release, I worked really, really hard on it.  Here's the list of fetishes included in the new content:

* Exhibitionism
* ENF
* Ball sucking
* Teabagging
* Ball worship
* Pubic hair
* Orgasm control
* Ruined orgasms
* Hands free orgasms
* Anal fingering
* Hickies
* Swim suits
* Cum eating

# Version 0.13.01

An edit I just made used the word "does" when I meant the word "doesn't".  Confusing as heck.  Since this update is all about immersion I felt silly not updating that.

# Version 0.13.00

For this release, I removed almost every "echoing headword".  When you have two sentences in a row that start with the same word, that's called an "echoing headword".  Getting rid of these was painstaking for two reasons.  

First, I had to go through all of the scenes and find all the echoing headwords.  That's difficult to do when you've got a novel worth of content to read through.  Over 700 lines had to be found and changed.  I programmed my editor to highlight the problems so I didn't have to find them on my own.

Second, it's not always easy to remove echoing headwords!  I spent a ton of mental energy thinking about how to remove some.  In some cases, I think I spent 30 minutes just thinking about how to do it.

But, as a result, I think the scenes are more immersive.  I'd like the players to focus on what I'm trying to convey, not how I convey it.  Echoing headwords can break immersion and ruin that experience.

Also in this release is a new image of Mia on the toilet cam.  There's no actual scat in the image, my artist just alludes to it.

Also I fixed this bug that only affected $5 pledges.  They would get a 404 error if they tried to view the cheats.  I think this was happening for a couple of releases so I'm surprised nobody reached out to me earlier!  Actually, I think that's kind of sweet.  Shows that you guys are pledging because you like what I'm putting out and that the cheat codes are just a bonus.  Thanks guys/gals!

Sorry if this release seems a little small.  I was on vacation for a few weeks and could only work on this in my spare time!  This update changed a ton of content, but only added 2k of words.  Making the total 168k words.

What's next?  Well, there will be two new teachers.  A swimming coach and a nurse.  The former will have a relatively tame exhibitionist scene and the latter will have a relatively hard vomit scene!

# Version 0.12.02

Now that the poll is over, I updated the "What's Next" section to say the next release will add a swim coach and a nurse.

# Version 0.12.01

Fixed a typo where I referred to Ms. Monet as Ms. Eigen in the trans girl bukakke scene.

# Version 0.12.00

Two major scenes added to this release.  The first is a bukakke scene where all the trans girls "paint" another trans girl's face.  The second is a camera scene where Olivia uses a pen to play with Mia's urethra.  I know the latter is a pretty rare fetish that will turn people off, but, as a reminder, these scenes are always optional and easy to avoid before anything happens.  I'll list the fetishes they add to the bottom of this, as some of them are spoilers.  They add an additional 12k words to the story, bringing the game's word count to 166k.

Fans proof read both of these scenes and were very helpful.  I just want to give them a huge "thank you" for taking the time to do that!

Here are the other changes that are in this release:

* 6 new images!  There's a scene with the trans girls tied to the metal easels, the trans bukakke scene (this is a first, normally the pictures for scenes come out at a later release), the scavenger hunt scene where Mia licks the students' clits, the drinking fountain scene where Olivia swipes up Mia's panties with her fingers, a picture of the mechanical counter used in the trans girl survey, and a picture of the measuring devices used in the scavenger hunt.  My artist actually made that last one weeks ago but I forgot to add it to the game.  That was pretty nice.  It's like finding an extra $20 in your pocket.
* All these images are now centered on the page, instead of being left aligned.
* My artist's image for the trans girl painting scene was different from how I described it, but I think her ideas made more sense than mine.  Therefore, I rewrote the intro of the trans girl painting scene to match the picture she came up with.  I'm pretty sure the rest of the story still works without modification, but let me know if there's anything there I missed.
* In Mia's camera scat scene, I added a description of how her anus is gaped immediately after she finishes.
* I majorly overhauled the code in the game.  I was using something called the Twine editor, but it became unbearably slow for me.  So I shifted to this new format called Twee.  Now I can use my editor of choice, vim, to write my story.  I've created all sorts of awesome macros with it.  It even comes with spell checking (what a modern idea!).  As you can imagine, this was a huge effort, but I'm much more productive now.
* I tweaked the $20 pledge reward so it's a one time thing.

The rest of these are bugs I fixed.  Most of these were reported from a single fan and I really appreciate it.
* At the end of the sensory deprivation epic, you could play both scenes where Olivia likes Mia and where Olivia hates Mia, even though you should only be able to play one or the other.
* The image where Ms. Monet is in a full bridge at the intro showed up earlier than it should have.  I moved it two passages later.
* If you got to the office then used the back button, you could get duplicate notifications and entries for yearbook entries.
* In the trans girl painting scene, it would say, "your first color is green", then when you painted a body part, it would say, "you painted the body part yellow."
* Added more yearbook choices descriptions what you did with Luna during the trans girl survey.

Here are the list of fetishes these new scenes contain.  Some of these are spoilers!

* Bukakke
* Cum eating
* Ball gag
* Frotting (touching 2 or more penises together)
* Face licking
* Urethra insertion / Sounding
* Watersports
* Orgasm denial

# Version 0.11.02

I fixed this bug where, upon leaving the yearbook, you could get duplicate camera scenes.  You could also use this same bug at the office over and over again to run through all the available camera scenes until you run out.  If you want more details about this, here's the comment where a fan discovered it: https://www.patreon.com/posts/surprise-academy-15253088

# Version 0.11.01

Major bug fix:  You could get stuck if you clicked on the "Yearbook" button when you were already on the "Yearbook".  This has been fixed by hiding the yearbook button if you're on the yearbook.

# Version 0.11.00

This update adds a roster of characters to the game!  Whenever you're introduced to a new character, they will be added to the school "yearbook".  It also keeps track of that character's major actions throughout the game and provides some background info you can't learn anywhere else.  This was an oft requested feature.  I think it'll make the game easier come back to later and to give insight into some of the character's motivations.

Here's a gif of it in action:  https://imgur.com/a/Ah8Xs (note, this is how the feature looks on mobile)

Eventually I'd like to have colored portraits of each of the characters in the yearbook so that you have a picture to go along with their names, but that's going to be pretty expensive so maybe I'll make it a patreon goal.

The game is now 154k words.  That's 4k more from the previous release, but all of these words are terse backgrounds/actions of the characters.  Each of the game's 24 characters have been described and there's also ~130 detailed notes to unlock.

There are two other minor changes I made:

- In the CBT scene with Bailey, I renamed the "second horniest girl" to the "tattooed girl".  I think that'll make her stand out more in your mind.  Referring to the "horniest" and "second horniest" was kind of awkward.
- There was a character named Erin that existed in a single passage during the trans girl survey.  I merged her in with Casey since she wasn't used in that passage.

# Version 0.10.02

Fixed a confusing typo where I said Casey mirrored Casey's posture.  This now says Casey mirrored Kira's posture.

# Version 0.10.01

Fixed a bug: You could see camera scenes during the sensory deprivation scene.  This didn't make sense since the girls in the camera scenes weren't wearing sensory deprivation head gear.  

# Version 0.10.00

This is a really large update with tons of fetishes, 20 to be exact.  And now the game has 150k words!  That's 17k more words for this release.

The theme of this update revolves around cameras installed on campus.  As principal, you spy on your students and teachers and catch them doing things they would never feel comfortable doing around your presence.  

This is a new game mechanic and here's how it works:  Every time you go to your office, there's a 50/50 chance a random camera scene will be available to play.  I added most of the scenes at the very beginning of the game so you're going to want to restart if you want to play them all.  Also, there are situations where going down a certain path of a scene will unlock new camera scenes.  Below I provided an incomplete walkthrough of how to find some of them, but there are cheats ($5 pledge reward) to go to each camera scene, so that's another way to view them all.

As a reminder, *you can avoid all the hard fetishes and there is plenty of warning before you run into them*.  Here are the fetishes added to this release:

* voyeurism
* exhibitionism
* ENF (embarrassed nude female)
* BBW
* yuri
* desperation
* cum eating
* shoe worship
* femdom (on trans girl)
* autofellatio (giving yourself oral sex)
* CBT (cock and ball torture)
* biting
* sadism
* hands free ejaculation (stopping stimulation before an imminent orgasm)
* ball busting
* trampling
* full weight trampling
* retrograde ejaculation (preventing semen from escaping your body when you orgasm)
* pee
* scat 

There are 10 new camera scenes to find, but some of them are pretty well hidden.  Here's how to find some of them:

* If you go to the Trans Girl survey class and you get to the passage where Olivia busts Bailey's balls, it'll unlock a sadistic camera scene later in the game.  If this is your kink, I'd really, really appreciate feedback on this camera scene.  Please reach out to me with your thoughts!
* Starting the foot fetish scene unlocks a date scene between Kira and Casey.
* If Jessie's nipple is tortured, it unlocks a scene in the shower.
* When you get to the Biochem week, it unlocks a scat scene.  But remember, you'll be warned with a chance to avoid it before anything happens.

Here are the other features added to this release:

* The images should now fit the screen if you're on a mobile device!  I didn't know this was even a problem until some fans informed me of it last release.  Hopefully this makes your mobile experience much more convenient.
* Two new images added.  Normally there'd be more like 6 in this time period, but, unfortunately, my artist has been very busy moving out of her place.  But her move should be over this week so things will be going back to normal.  The images are giving Fifa, the trans girl, blue balls and Mia squirting on Olivia.
* This happened in a previous release but it's a big deal so I want to mention it again: You can now play multiple sensory deprivation dorm room scenes in the same play through.  Before this change, you had to pick one.
* Similarly, you can now unlock multiple engineering class devices in one play through.
* There was a girl named Katie in the first PE class that never came up again.  She no longer exists, I replaced her with Kira.
* I've changed Kira so she's now a BBW (big beautiful woman).
* The site is now https instead of http.  Yay, security!
* The fetish picker now has an effect on whether the t____ shave m____ in the shaving scene.
* You could shave the m_____ at the same time you were doing sensory deprivation which didn't make sense because the m____ would not be in sensory deprivation.  Fixed.

# Version 0.09.02

This is a relatively large patch update.  Here's what I did:

1. I made it possible to play multiple sensory deprivation dorm room endings in one play through.
2. I had a bug where you could visit the mom's showers while the sensory deprivation experiment was going on.  If you did that, it doesn't make much sense because the mom's weren't wearing hoods.  The solution I came up with is that you can't play one scene until you finish the other.  
3. You could say, "I don't want twincest" and you'd still be able to visit the twins as they shave their mom.  I fixed this.

# Version 0.09.01

There was a link named DaughtersShaveMothers3.  I renamed it to say "Continue."

# Version 0.09

* If you like mother/daughter incest, you'll like this update!  I added a new, large scene that takes place in the gym locker room.  You see, Mrs. Ball noticed the mothers have a little dress code violation.  She and you force the daughters to help their mothers fix the issue, in a humiliating fashion.  I don't want to give too much away.  Enjoy!  I'll put the list of fetishes at the bottom so you can avoid it if you don't like spoilers.
* The game now has 133k words total, meaning this version added 12k words to the game.  
* I added 5 new, commissioned images to the game!
* The game now has a Back button!  I had no idea people wanted this until two fans told me last release, so I gave a poll and it was almost unanimous.  Remember to reach out to me at any time with your suggestions.  I love hearing them and I really do my best to incorporate them into the game.
* I fixed a lot of tense issues and omniscient voice in the old scene where mother's give their daughters a sexual massage.
* I clarified that the trans students go to the dorms at the end of the day, not "home"

OK and now for the fetishes of the new scene.  Close your eyes if you consider this a spoiler ;)

* Daughter/Mother
* Inappropriate touching
* Humiliation
* Hairy
* Shaving

# Version 0.08

This update adds a new, long hucow scene at the end of the game with a bunch of fetishes:

* Hucow
* Lactation
* Kissing
* Puffy nipples
* Milking
* Blindfolding
* Cheating
* Light asphyxiation

If you played the first lactation scene, this one has almost twice as many passages.  So if you liked that one, this one has a lot more content and is about 12k words.  Now the game is a total of 121k words!  Jessie's had a lot of changes.  I don't want to spoil more than I already have.

There are other changes in this release.  Here's what's happened:

1. Now Jessie shows a little more fear toward you if you tortured her breast in the first PE class.
2. When you finish the aphrodisiac scene you now take some aphrodisiac cream with you to use later.  If you already played the aphrodisiac scene and start from that save, you won't get it :(  If you put `has_aphrodisiac=true` at the end of your URL, it'll add it to your inventory.  I didn't want people to have to play the game all over again just to get the aphrodisiac.
3. There's some foreshadowing of Jessie's changes in Olivia's fisting scene.
4. When you use the semen jar in the fisting scene, you no longer have the jar (this doesn't really have any effect on the game yet).
5. Now the version on the first page of the game will be a link.  Clicking on it will let you see the changelog.
6. I added some anonymized analytics to the game so I have a better idea of what scenes people enjoy and dislike.  
7. I made it possible to leave the foot fetish scene very early on with a link.
8. Added 3 new images to the game.  My favorite is of a nude Olivia being embarrassed in front of the class.

Here's something you should know: I changed a lot of the code at the end of the game for the hucow scene to be triggered at the right time.  I'm a little worried that if you have a save on the last week, it may not work as expected (see point 2 above for an example).  If you have any trouble with this and you *really* don't want to restart (that'll definitely fix it), shoot me a message and I'll see if I can help you out with your situation.

What's next?  Well I gave a pledge poll and people were most interested in a scene where the daughters shave their mothers.  So that'll be what I work on :)

# Version 0.07.01

This is a small update that includes things I should have done but forgot (oops).

1. I spell checked the game.  There were a few typos in the fisting scene.
2. I changed the fetish picker blurb.  Hopefully it makes things more clear.
3. I updated the "What's Next" passage when you get to the end of the game.
4. I made it so that when you use the semen jar during anal fisting, you lose the contents.

# Version 0.07

This is a massive update!  It consists of one long scene where the main theme is fisting, but it contains a ton of other fetishes, too.  There are now 110k words in the game.  That's 20k more words from the last release.

I know a lot of these fetishes are pretty hard and not to everyone's tastes.  That's why I've made most of them avoidable with a warning before they happen.  You don't have to worry about accidentally running into one while you're playing.

Here's a list of fetishes included in this scene:

* Blackmail/threatening
* Embarrassed nude female
* Innocence
* Vaginal fisting
* Anal fisting
* Gaping
* Forced orgasms
* Anal Orgasms
* Painal
* Stomach distention
* Fisting to elbow
* Fisting from ass to vagina
* Trans semen
* Queefing
* Diapers
* Enemas
* Enema drinking (from a tube)
* Scat

I added 5 new images to the game: The nude full bridge pose from the intro, the downward dog pose in PE class, feeding mom soup, the twins 69ing in the dorm, and the breast auto-lactating.  Trying to keep these descriptions vague to avoid spoilers.

Oh, and this is a big change: The previous version of the game will be available to the public for all to download and share.  The downloadable version was a pledge-only reward, but now I'm doing early access for pledges instead.   You can find the download link on the patreon page: http://www.patreon.com/AcademyOfFetishes 

I hope you enjoy the new scene!  

# Version 0.06

A lot happened in this release and most of it was not fun, but I think it will be worth it to those who play the game.

1. I rewrote ALL the code.  The game is ~90k words and I had to look through all of it to achieve this.  But, it enabled me to add these two new features:
2. There are now multiple save slots!  There used to be only one.  With lots and lots of branches, this meant you had to play the game multiple times to experience everything.  I'm sure that was painful.  But now with multiple save slots it should be a lot easier to experience everything.
3. There's a "Fetish Picker" at the beginning of the game.  Don't like nipple torture or lactation?  Now you can configure the game so you don't run into fetishes that you dislike.  I'll continue to write scenes that give you fair warning before you bump into the hard stuff, but if you really hate a fetish this will allow you to play without worry of experiencing it.
4. Added 3 new pieces of commissioned artwork to the game.
  - A pre-rimjob scene between Lucy and Mia
  - A pee scene between Olivia and Mia
  - A picture of Anna spreading Hannah's labia (extreme close up)
  - I'm working on one with Sarah and her mom, but it wasn't finished in time for this release.
5. When you finish the foot fetish math scene, you accidentally take a ruler with you.
6. I slightly modified the math class scene so there's more classroom presence described.  You and Mrs. Eigen periodically "play defense" so the two students continue their task.
7. You can use the ruler from math class if you bring it to PE class to torture/spank Jessie's breast.
8. I had this problem with omniscient narration in the first two art scenes.  ie., You could read the teacher's/student's thoughts.  This bugged the crap out of me for a month and I finally fixed it.  They've been converted so Ms. Monet confesses what happened to you.  I'd estimate 25% of the first scene (Ms. Monet takes close up photos of the students' labia) was rewritten and 50% of the second scene (Ms. Monet has the students sketch another girl's photo from the first class) was rewritten.  You may want to try them again even if you've already played it.
9. The first art scene had a lot of small passages.  I compressed a lot of them together to make them similar to the passage sizes of the other scenes.
10. Added new cheats to jump to all the scenes described above.

# Version 0.05

I'm very excited to say you can now unlock a Bio Chemistry lab.  This unlocks two new scenes with many fetishes!  

1. The first scene is an aphrodisiac scene.  You apply it to one of your students and make her uncontrollably horny.  This contains hand cuffs, group fondling, forced orgasm, multiple orgasms, squirting, ahegao, and mind break.
2. The second scene is a lactation scene.  It's pretty straight forward, but you squirt a student's milk onto a mirror, into your drink, into your mouth, and there's also a bit of what I call auto-lactation: Lactating without squeezing.

There are some other points worth mentioning that do not relate to scenes:

1. I changed "Jesse" to "Jessie".  I was using the male variant of the name :(
2. I don't know why, but many people were interpreting the clothes pin in the PE class as a safety pin.  I included a photo of a clothes pin so people won't make that mistake. 
3. I purchased the www.academyoffetishes.com domain!  Now things are more official

# Version 0.04

This is a major release!  I'm very excited for these features.

1. First piece of artwork added to the Trans Girl Survey scene!  Much more art to come!  I'm going to spend as much of my patreon income toward new art as I can.
1. Add a changelog and started versioning the game.  You can see the version on the load page
1. Added a **massive** sensory deprivation act.  This act adds over 40% more content to the game!  There are 8 scenes to find and most have their own variations of outcomes.  Here are the scenes added:
  - There are two romantic/yuri scenes between two students.  This includes hickies, biting, light spanking, hard spanking, crying, and rim jobs.  Yeah... romantic.
  - There's a twincest scene where one suspects the other is her twin, the other has no idea.  This includes pet play, pet talk, 69, the taboo of incest, and pussy juice play
  - There's two scenes where a large trans girl has sex with a petite female student.  This includes coaching, ear play, and cream pies.
  - There's a scene where a mom masturbates in front of her daughter (unknowingly).  This has a lot of dirty talk in it.
  - There's a sleeping fetish scene where you and another student molest a sleeping student.  This scene also has armpit play.
  - There's a foursome with you, a teacher, a daughter and her mother.  The mother is the focus.  There's a small scene at the end involving food (soup) and spit, but it's skippable.
  - There's a bathroom scene between two students.  It might make more sense to classify this as 2.5 scenes.  It has 3 variations, one of them is very disgusting but, of course, optional.  It includes pee play, wiping another student, and the disgusting scene is more toilet focused but still pee play.
  - There's a scene where they take off their sensory deprivation hoods
1. I fixed word tense issues in the scavenger hunt scene.
1. I wrote a description of what each cheat does (you have to be a pledge to see these cheats).
1. I added a ton of cheats.  You can change variables now, like what week you're in or if you've unlocked certain transfer students.  This helps me write automated tests so I can catch bugs before you guys do :)
1. I fixed a bug where you could see a pre-cum scene when you wanted to see ruined orgasms during the trans girl survey.
1. Updated the "Coming soon" passage when you reach the end of the game.  Maybe Hucows will be next?

# Version 0.03

Hello all! Just wanted to announce a new minor release I just made. Here are the changes it contains:

    - When you reach the end of the game, it now says what's planned for future releases instead of leaving you with a blank screen
    - I changed all the usage of "futa" and "futanari" to be "trans girl". The former was technically incorrect and misleading so it was frustrating. Sorry it took so long!
    - I changed a lot of tense inconsistencies in the first Trans Girl Survey scene (the first scene).
    - I made an effort to re-introduce each trans girl in the Trans Girl Survey scene each time you visit a group. There's a lot of names thrown at you all at once. I hope this makes it easier to remember who's who in the scene.
    - I just learned there's a fetish called ENF. It stands for Embarrassed Nude Female. My game has tons of that fetish! I added that to the list of fetishes on the about page.

# Version 0.02
I'm excited to announce I've just made another large release. You can play it in your browser or download it on Patreon. This release adds close to 10k words. Here's a list of new features in this update:

    - A very long trans girl/futanari scene. It's very unique. In fact I've been told by some experts that I may have invented a new fetish?
    - A foot fetish scene. Do you prefer toe sucking or licking the arch? Well this scene has both and more. It's actually my most innocent scene yet.
    - A new bullying scene in the hallway. It all starts when one of the students swipes her finger along another's camel toe.
    - When you get to week 3 you unlock a new engineering class. Think of all the cruel and unusual devices you will make!
    - You can now save and load the game
    - A ton of typos are fixed.
    - A ton of grammatical errors, mostly related to inappropriate past and present tense changes are fixed.
    - A downloadable version of the game. Now you can play offline! (Warning: This is only available to patreon supporters)
    - A few new cheats to use. These let you skip directly to the scene you want to play. (Warning: This is only available to patreon supporters) 

# Version 0.01

There is a rather large Futanari (MtF) scene in the game. If you play from start to finish, you'll run into it eventually. Here are the fetishes in this scene (most are optional):

    - Ball/Scrotum worship
    - Edging
    - Ruined orgasms
    - Blue balls
    - Anus worship
    - Fingering
    - Rimjobs
    - Self cum eating
    - Farting (optional!) 
